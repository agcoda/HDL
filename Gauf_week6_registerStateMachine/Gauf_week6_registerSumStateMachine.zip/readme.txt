registerSumStateMachine fills 4 register_4bit modules with input and outputs a 6 bit sum of their contents.

6 bits required to hold the largest input valuex4 = 60

The state machine output will be X until all registers are filled, so an initialization of 4 cycles of 0 to fill all registers is a must. 


*Note testbench sim was generated and annoted before a file rename from registerStateMachine to memStateMachine, file was otherwise unchanged.